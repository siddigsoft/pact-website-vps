import { TeamMember } from "@/types";
import { generateSlug } from "@/lib/utils";

// Use fallback mechanism in the components instead of importing a placeholder image
const teamMemberImage = '';

// Helper function to generate a slug from the team member's name
const createTeamMemberSlug = (name: string) => generateSlug(name);

export const teamMembers: TeamMember[] = [
  // Monitoring, Evaluation & Learning
  {
    id: 1,
    name: "Dr. Karamallah Ali",
    position: "Senior MEL Advisor",
    department: "Monitoring, Evaluation & Learning",
    location: "Global",
    bio: "Dr. Karamallah Ali leads our Monitoring, Evaluation & Learning practice, bringing extensive experience in program evaluation and impact assessment.",
    expertise: ["Program Evaluation", "Impact Assessment", "Learning Systems", "MEL Strategy"],
    education: "PhD in Evaluation Studies",
    achievements: ["Led multiple large-scale program evaluations", "Developed innovative MEL frameworks", "Published research in evaluation methodologies"],
    quote: "Effective monitoring and evaluation is the cornerstone of successful development programs.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dr. Karamallah Ali"),
    metaDescription: "Dr. Karamallah Ali is the Senior MEL Advisor at PACT Consultancy, leading our Monitoring, Evaluation & Learning practice.",
    contact: {
      email: "karamallah.ali@pactconsultancy.com",
      linkedin: "linkedin.com/in/karamallahali"
    }
  },
  {
    id: 2,
    name: "Intisar Salih",
    position: "Evaluation & Learning Specialist",
    department: "Monitoring, Evaluation & Learning",
    location: "Global",
    bio: "Intisar specializes in evaluation methodologies and learning systems development, helping organizations measure and improve their impact.",
    expertise: ["Evaluation Design", "Learning Systems", "Data Analysis", "Capacity Building"],
    education: "MSc in Development Studies",
    achievements: ["Designed evaluation frameworks for major development programs", "Implemented learning systems across multiple organizations"],
    quote: "Learning is the bridge between evaluation and impact.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Intisar Salih"),
    metaDescription: "Intisar Salih is an Evaluation & Learning Specialist at PACT Consultancy, focusing on evaluation methodologies and learning systems.",
    contact: {
      email: "intisar.salih@pactconsultancy.com",
      linkedin: "linkedin.com/in/intisarsalih"
    }
  },
  {
    id: 3,
    name: "Dalmas Menya",
    position: "Learning Systems Lead",
    department: "Monitoring, Evaluation & Learning",
    location: "Global",
    bio: "Dalmas leads our learning systems initiatives, focusing on developing robust frameworks for organizational learning and knowledge management.",
    expertise: ["Learning Systems", "Knowledge Management", "Capacity Development", "Organizational Learning"],
    education: "MSc in Organizational Development",
    achievements: ["Developed learning systems for international organizations", "Implemented knowledge management frameworks"],
    quote: "Effective learning systems transform data into actionable knowledge.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dalmas Menya"),
    metaDescription: "Dalmas Menya is the Learning Systems Lead at PACT Consultancy, focusing on organizational learning and knowledge management.",
    contact: {
      email: "dalmas.menya@pactconsultancy.com",
      linkedin: "linkedin.com/in/dalmasmenya"
    }
  },

  // Socio-economic Studies & Development
  {
    id: 4,
    name: "Dr. Habtu Assefa",
    position: "Senior Socio-economic Analyst",
    department: "Socio-economic Studies & Development",
    location: "Global",
    bio: "Dr. Habtu brings extensive experience in socio-economic analysis and development research, helping organizations understand and address complex development challenges.",
    expertise: ["Socio-economic Analysis", "Development Research", "Policy Analysis", "Impact Assessment"],
    education: "PhD in Development Economics",
    achievements: ["Led major socio-economic studies", "Published research in development economics", "Advised international development organizations"],
    quote: "Understanding socio-economic dynamics is key to sustainable development.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dr. Habtu Assefa"),
    metaDescription: "Dr. Habtu Assefa is a Senior Socio-economic Analyst at PACT Consultancy, specializing in development research and analysis.",
    contact: {
      email: "habtu.assefa@pactconsultancy.com",
      linkedin: "linkedin.com/in/habtuassefa"
    }
  },
  {
    id: 5,
    name: "Abdelmajid Khojali",
    position: "Development Researcher",
    department: "Socio-economic Studies & Development",
    location: "Global",
    bio: "Abdelmajid specializes in development research and analysis, focusing on socio-economic trends and their implications for development programs.",
    expertise: ["Development Research", "Data Analysis", "Policy Research", "Impact Assessment"],
    education: "MSc in Development Studies",
    achievements: ["Conducted extensive development research", "Published research papers on development issues"],
    quote: "Research-driven insights are the foundation of effective development programs.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Abdelmajid Khojali"),
    metaDescription: "Abdelmajid Khojali is a Development Researcher at PACT Consultancy, focusing on socio-economic research and analysis.",
    contact: {
      email: "abdelmajid.khojali@pactconsultancy.com",
      linkedin: "linkedin.com/in/abdelmajidkhojali"
    }
  },

  // Poverty Reduction & MSME Development
  {
    id: 6,
    name: "Dr. Mohamed Yousif",
    position: "Lead Consultant, MSME Strategies",
    department: "Poverty Reduction & MSME Development",
    location: "Global",
    bio: "Dr. Mohamed leads our MSME development strategies, bringing extensive experience in poverty reduction and enterprise development.",
    expertise: ["MSME Development", "Poverty Reduction", "Enterprise Development", "Strategic Planning"],
    education: "PhD in Development Economics",
    achievements: ["Developed MSME strategies for multiple countries", "Led poverty reduction programs", "Published research on enterprise development"],
    quote: "Empowering MSMEs is key to sustainable poverty reduction.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dr. Mohamed Yousif"),
    metaDescription: "Dr. Mohamed Yousif is the Lead Consultant for MSME Strategies at PACT Consultancy, focusing on poverty reduction and enterprise development.",
    contact: {
      email: "mohamed.yousif@pactconsultancy.com",
      linkedin: "linkedin.com/in/mohamedyousif"
    }
  },
  {
    id: 7,
    name: "Tefera Tesfaye",
    position: "Inclusive Economy Specialist",
    department: "Poverty Reduction & MSME Development",
    location: "Global",
    bio: "Tefera specializes in developing inclusive economic strategies and programs that benefit marginalized communities.",
    expertise: ["Inclusive Economy", "Economic Development", "Community Development", "Program Design"],
    education: "MSc in Development Economics",
    achievements: ["Designed inclusive economic programs", "Implemented community development initiatives"],
    quote: "Inclusive economic growth benefits everyone in society.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Tefera Tesfaye"),
    metaDescription: "Tefera Tesfaye is an Inclusive Economy Specialist at PACT Consultancy, focusing on inclusive economic development.",
    contact: {
      email: "tefera.tesfaye@pactconsultancy.com",
      linkedin: "linkedin.com/in/teferatesfaye"
    }
  },
  {
    id: 8,
    name: "Adil Sadoq",
    position: "Livelihoods Expert",
    department: "Poverty Reduction & MSME Development",
    location: "Global",
    bio: "Adil specializes in livelihoods development and poverty reduction strategies, helping communities build sustainable economic opportunities.",
    expertise: ["Livelihoods Development", "Poverty Reduction", "Community Development", "Economic Empowerment"],
    education: "MSc in Development Studies",
    achievements: ["Developed livelihoods programs", "Implemented poverty reduction strategies"],
    quote: "Sustainable livelihoods are the foundation of community resilience.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Adil Sadoq"),
    metaDescription: "Adil Sadoq is a Livelihoods Expert at PACT Consultancy, focusing on sustainable livelihoods development.",
    contact: {
      email: "adil.sadoq@pactconsultancy.com",
      linkedin: "linkedin.com/in/adilsadoq"
    }
  },

  // Technology & Digital Transformation
  {
    id: 9,
    name: "Sunil Varghese",
    position: "Digital Innovation Lead",
    department: "Technology & Digital Transformation",
    location: "Global",
    bio: "Sunil leads our digital innovation initiatives, focusing on leveraging technology for development impact.",
    expertise: ["Digital Innovation", "Technology Strategy", "Digital Transformation", "Innovation Management"],
    education: "MSc in Information Technology",
    achievements: ["Led digital transformation projects", "Developed innovative technology solutions"],
    quote: "Digital innovation is a catalyst for development impact.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Sunil Varghese"),
    metaDescription: "Sunil Varghese is the Digital Innovation Lead at PACT Consultancy, focusing on technology and digital transformation.",
    contact: {
      email: "sunil.varghese@pactconsultancy.com",
      linkedin: "linkedin.com/in/sunilvarghese"
    }
  },
  {
    id: 10,
    name: "Melaku Kebede",
    position: "IT & Transformation Consultant",
    department: "Technology & Digital Transformation",
    location: "Global",
    bio: "Melaku specializes in IT strategy and digital transformation, helping organizations leverage technology for development impact.",
    expertise: ["IT Strategy", "Digital Transformation", "Technology Implementation", "Change Management"],
    education: "MSc in Information Systems",
    achievements: ["Implemented IT strategies", "Led digital transformation initiatives"],
    quote: "Technology is a powerful enabler of development impact.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Melaku Kebede"),
    metaDescription: "Melaku Kebede is an IT & Transformation Consultant at PACT Consultancy, focusing on technology implementation and digital transformation.",
    contact: {
      email: "melaku.kebede@pactconsultancy.com",
      linkedin: "linkedin.com/in/melakukebede"
    }
  },

  // Program/Project Development & Assessment
  {
    id: 11,
    name: "Tariq Monim",
    position: "Senior Program Advisor",
    department: "Program/Project Development & Assessment",
    location: "Global",
    bio: "Tariq brings extensive experience in program development and assessment, helping organizations design and implement effective development programs.",
    expertise: ["Program Development", "Project Assessment", "Strategic Planning", "Capacity Building"],
    education: "MSc in Development Management",
    achievements: ["Developed major development programs", "Led program assessments", "Built organizational capacity"],
    quote: "Effective programs are built on solid foundations of assessment and planning.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Tariq Monim"),
    metaDescription: "Tariq Monim is a Senior Program Advisor at PACT Consultancy, focusing on program development and assessment.",
    contact: {
      email: "tariq.monim@pactconsultancy.com",
      linkedin: "linkedin.com/in/tariqmonim"
    }
  },
  {
    id: 12,
    name: "Seifeldin Abbaro",
    position: "Senior Program Advisor",
    department: "Program/Project Development & Assessment",
    location: "Global",
    bio: "Seifeldin specializes in program development and assessment, helping organizations design and implement effective development initiatives.",
    expertise: ["Program Development", "Project Assessment", "Strategic Planning", "Capacity Building"],
    education: "MSc in Development Studies",
    achievements: ["Developed development programs", "Led program assessments", "Built organizational capacity"],
    quote: "Strategic program development is key to achieving development impact.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Seifeldin Abbaro"),
    metaDescription: "Seifeldin Abbaro is a Senior Program Advisor at PACT Consultancy, focusing on program development and assessment.",
    contact: {
      email: "seifeldin.abbaro@pactconsultancy.com",
      linkedin: "linkedin.com/in/seifeldinabbaro"
    }
  },

  // Public Health & Nutrition
  {
    id: 13,
    name: "Dr. Ibrahim Ahmed Bani",
    position: "Global Health Expert",
    department: "Public Health & Nutrition",
    location: "Global",
    bio: "Dr. Ibrahim brings extensive experience in global health, focusing on public health systems and nutrition programs.",
    expertise: ["Global Health", "Public Health Systems", "Nutrition Programs", "Health Policy"],
    education: "PhD in Public Health",
    achievements: ["Led global health initiatives", "Developed nutrition programs", "Published health research"],
    quote: "Health is a fundamental human right and a cornerstone of development.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dr. Ibrahim Ahmed Bani"),
    metaDescription: "Dr. Ibrahim Ahmed Bani is a Global Health Expert at PACT Consultancy, focusing on public health and nutrition.",
    contact: {
      email: "ibrahim.bani@pactconsultancy.com",
      linkedin: "linkedin.com/in/ibrahimbani"
    }
  },
  {
    id: 14,
    name: "Dr. Nasredin Elamin",
    position: "Public Health & Nutrition Specialist",
    department: "Public Health & Nutrition",
    location: "Global",
    bio: "Dr. Nasredin specializes in public health and nutrition, helping organizations develop and implement effective health programs.",
    expertise: ["Public Health", "Nutrition", "Health Systems", "Program Development"],
    education: "PhD in Public Health",
    achievements: ["Developed health programs", "Implemented nutrition initiatives", "Published health research"],
    quote: "Effective health programs combine scientific evidence with community needs.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dr. Nasredin Elamin"),
    metaDescription: "Dr. Nasredin Elamin is a Public Health & Nutrition Specialist at PACT Consultancy, focusing on health program development.",
    contact: {
      email: "nasredin.elamin@pactconsultancy.com",
      linkedin: "linkedin.com/in/nasredinelamin"
    }
  },

  // Agricultural and Land Use Services
  {
    id: 15,
    name: "Dr. Abdelrahman Khidir",
    position: "Agriculture & Land Use Advisor",
    department: "Agricultural and Land Use Services",
    location: "Global",
    bio: "Dr. Abdelrahman specializes in agricultural development and land use planning, helping organizations implement sustainable agricultural practices.",
    expertise: ["Agricultural Development", "Land Use Planning", "Sustainable Agriculture", "Rural Development"],
    education: "PhD in Agricultural Sciences",
    achievements: ["Developed agricultural programs", "Implemented land use plans", "Published agricultural research"],
    quote: "Sustainable agriculture is key to food security and environmental protection.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dr. Abdelrahman Khidir"),
    metaDescription: "Dr. Abdelrahman Khidir is an Agriculture & Land Use Advisor at PACT Consultancy, focusing on sustainable agricultural development.",
    contact: {
      email: "abdelrahman.khidir@pactconsultancy.com",
      linkedin: "linkedin.com/in/abdelrahmankhidir"
    }
  },
  {
    id: 16,
    name: "Dr. Abdullatif Jjaimi",
    position: "Agriculture & Land Use Advisor",
    department: "Agricultural and Land Use Services",
    location: "Global",
    bio: "Dr. Abdullatif brings extensive experience in agricultural development and land use planning, focusing on sustainable practices.",
    expertise: ["Agricultural Development", "Land Use Planning", "Sustainable Agriculture", "Rural Development"],
    education: "PhD in Agricultural Sciences",
    achievements: ["Developed agricultural programs", "Implemented land use plans", "Published agricultural research"],
    quote: "Sustainable land use is essential for agricultural development.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dr. Abdullatif Jjaimi"),
    metaDescription: "Dr. Abdullatif Jjaimi is an Agriculture & Land Use Advisor at PACT Consultancy, focusing on sustainable agricultural development.",
    contact: {
      email: "abdullatif.jjaimi@pactconsultancy.com",
      linkedin: "linkedin.com/in/abdullatifjjaimi"
    }
  },

  // Education & Learning
  {
    id: 17,
    name: "Prof. Robert Deng",
    position: "Education Policy Expert",
    department: "Education & Learning",
    location: "Global",
    bio: "Prof. Robert brings extensive experience in education policy and learning systems, helping organizations develop effective education programs.",
    expertise: ["Education Policy", "Learning Systems", "Curriculum Development", "Education Reform"],
    education: "PhD in Education",
    achievements: ["Developed education policies", "Implemented learning systems", "Published education research"],
    quote: "Quality education is the foundation of sustainable development.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Prof. Robert Deng"),
    metaDescription: "Prof. Robert Deng is an Education Policy Expert at PACT Consultancy, focusing on education policy and learning systems.",
    contact: {
      email: "robert.deng@pactconsultancy.com",
      linkedin: "linkedin.com/in/robertdeng"
    }
  },
  {
    id: 18,
    name: "Dr. Herine Otieno",
    position: "Learning Systems Consultant",
    department: "Education & Learning",
    location: "Global",
    bio: "Dr. Herine specializes in learning systems and education development, helping organizations implement effective learning programs.",
    expertise: ["Learning Systems", "Education Development", "Curriculum Design", "Capacity Building"],
    education: "PhD in Education",
    achievements: ["Developed learning systems", "Implemented education programs", "Published education research"],
    quote: "Effective learning systems empower individuals and communities.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dr. Herine Otieno"),
    metaDescription: "Dr. Herine Otieno is a Learning Systems Consultant at PACT Consultancy, focusing on learning systems and education development.",
    contact: {
      email: "herine.otieno@pactconsultancy.com",
      linkedin: "linkedin.com/in/herineotieno"
    }
  },

  // Peace Building & Conflict Resolution
  {
    id: 19,
    name: "Chrysanthus Ache",
    position: "Conflict Mitigation Specialist",
    department: "Peace Building & Conflict Resolution",
    location: "Global",
    bio: "Chrysanthus specializes in conflict mitigation and peace building, helping organizations develop effective conflict resolution strategies.",
    expertise: ["Conflict Mitigation", "Peace Building", "Conflict Resolution", "Community Engagement"],
    education: "MSc in Peace and Conflict Studies",
    achievements: ["Developed conflict resolution programs", "Implemented peace building initiatives", "Published conflict research"],
    quote: "Sustainable peace requires addressing root causes of conflict.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Chrysanthus Ache"),
    metaDescription: "Chrysanthus Ache is a Conflict Mitigation Specialist at PACT Consultancy, focusing on peace building and conflict resolution.",
    contact: {
      email: "chrysanthus.ache@pactconsultancy.com",
      linkedin: "linkedin.com/in/chrysanthusache"
    }
  },
  {
    id: 20,
    name: "Elhussein Elkhazin",
    position: "Conflict Mitigation Specialist",
    department: "Peace Building & Conflict Resolution",
    location: "Global",
    bio: "Elhussein brings extensive experience in conflict mitigation and peace building, helping organizations develop effective conflict resolution strategies.",
    expertise: ["Conflict Mitigation", "Peace Building", "Conflict Resolution", "Community Engagement"],
    education: "MSc in Peace and Conflict Studies",
    achievements: ["Developed conflict resolution programs", "Implemented peace building initiatives", "Published conflict research"],
    quote: "Peace building is a long-term process that requires commitment and collaboration.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Elhussein Elkhazin"),
    metaDescription: "Elhussein Elkhazin is a Conflict Mitigation Specialist at PACT Consultancy, focusing on peace building and conflict resolution.",
    contact: {
      email: "elhussein.elkhazin@pactconsultancy.com",
      linkedin: "linkedin.com/in/elhusseinelkhazin"
    }
  },

  // Environmental Studies & Climate Change
  {
    id: 21,
    name: "Dr. Omer Abdalla M. Egemi",
    position: "Climate & Environment Consultant",
    department: "Environmental Studies & Climate Change",
    location: "Global",
    bio: "Dr. Omer specializes in climate change and environmental studies, helping organizations develop sustainable environmental strategies.",
    expertise: ["Climate Change", "Environmental Studies", "Sustainability", "Environmental Policy"],
    education: "PhD in Environmental Science",
    achievements: ["Developed climate change strategies", "Implemented environmental programs", "Published environmental research"],
    quote: "Addressing climate change requires collective action and innovative solutions.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dr. Omer Abdalla M. Egemi"),
    metaDescription: "Dr. Omer Abdalla M. Egemi is a Climate & Environment Consultant at PACT Consultancy, focusing on climate change and environmental studies.",
    contact: {
      email: "omer.egemi@pactconsultancy.com",
      linkedin: "linkedin.com/in/omeregemi"
    }
  },
  {
    id: 22,
    name: "Dr. Osman Babikir",
    position: "Climate & Environment Consultant",
    department: "Environmental Studies & Climate Change",
    location: "Global",
    bio: "Dr. Osman brings extensive experience in climate change and environmental studies, helping organizations develop sustainable environmental strategies.",
    expertise: ["Climate Change", "Environmental Studies", "Sustainability", "Environmental Policy"],
    education: "PhD in Environmental Science",
    achievements: ["Developed climate change strategies", "Implemented environmental programs", "Published environmental research"],
    quote: "Environmental sustainability is key to long-term development.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Dr. Osman Babikir"),
    metaDescription: "Dr. Osman Babikir is a Climate & Environment Consultant at PACT Consultancy, focusing on climate change and environmental studies.",
    contact: {
      email: "osman.babikir@pactconsultancy.com",
      linkedin: "linkedin.com/in/osmanbabikir"
    }
  },

  // Renewable Energy
  {
    id: 23,
    name: "Intisar Salih",
    position: "Renewable Energy & Sustainable Infrastructure Expert",
    department: "Renewable Energy",
    location: "Global",
    bio: "Intisar specializes in renewable energy and sustainable infrastructure, helping organizations develop and implement sustainable energy solutions.",
    expertise: ["Renewable Energy", "Sustainable Infrastructure", "Energy Policy", "Project Development"],
    education: "MSc in Renewable Energy",
    achievements: ["Developed renewable energy projects", "Implemented sustainable infrastructure", "Published energy research"],
    quote: "Renewable energy is key to sustainable development.",
    image: teamMemberImage,
    slug: createTeamMemberSlug("Intisar Salih"),
    metaDescription: "Intisar Salih is a Renewable Energy & Sustainable Infrastructure Expert at PACT Consultancy, focusing on renewable energy and sustainable infrastructure.",
    contact: {
      email: "intisar.salih@pactconsultancy.com",
      linkedin: "linkedin.com/in/intisarsalih"
    }
  }
];

export const leadershipTeam = teamMembers.filter(
  member => member.position.includes("Lead") || member.position.includes("Senior") || member.position.includes("Director")
);

export const departmentTeams = {
  "Monitoring, Evaluation & Learning": teamMembers.filter(member => member.department === "Monitoring, Evaluation & Learning"),
  "Socio-economic Studies & Development": teamMembers.filter(member => member.department === "Socio-economic Studies & Development"),
  "Poverty Reduction & MSME Development": teamMembers.filter(member => member.department === "Poverty Reduction & MSME Development"),
  "Technology & Digital Transformation": teamMembers.filter(member => member.department === "Technology & Digital Transformation"),
  "Program/Project Development & Assessment": teamMembers.filter(member => member.department === "Program/Project Development & Assessment"),
  "Public Health & Nutrition": teamMembers.filter(member => member.department === "Public Health & Nutrition"),
  "Agricultural and Land Use Services": teamMembers.filter(member => member.department === "Agricultural and Land Use Services"),
  "Education & Learning": teamMembers.filter(member => member.department === "Education & Learning"),
  "Peace Building & Conflict Resolution": teamMembers.filter(member => member.department === "Peace Building & Conflict Resolution"),
  "Environmental Studies & Climate Change": teamMembers.filter(member => member.department === "Environmental Studies & Climate Change"),
  "Renewable Energy": teamMembers.filter(member => member.department === "Renewable Energy")
};

export const allDepartments = Object.keys(departmentTeams);