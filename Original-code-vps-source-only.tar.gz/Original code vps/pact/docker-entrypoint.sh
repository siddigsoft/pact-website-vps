#!/bin/sh
set -e

# Wait for postgres to be ready
echo "Waiting for PostgreSQL to be ready..."
/wait-for-it.sh postgres:5432 -t 60

# Run database migrations
echo "Running database migrations..."
npx drizzle-kit push

# Start the application
echo "Starting the application..."
exec "$@"